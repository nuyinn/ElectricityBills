package com.example.discountcalculatorbasic;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {


        TextView tvOutput;
        EditText etValue, etRebate;
        Button btnCalculate;

        Toolbar myToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        tvOutput = findViewById(R.id.tvOutput);
        etRebate = findViewById(R.id.etRebate);
        etValue = findViewById((R.id.etValue));
        btnCalculate = findViewById(R.id.btnCalculate);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);


        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double value, rebate, cost, finalCost;

                try {

                    value = Double.parseDouble(etValue.getText().toString());
                    rebate = Double.parseDouble(etRebate.getText().toString());

                    if (value <= 200) {
                        cost = value * 0.218;
                    } else if (value >= 201 && value <= 300) {
                        cost = (200 * 0.218) + ((value - 200) * 0.334);
                    } else if (value >= 301 && value <= 600) {
                        cost = (200 * 0.218) + (100 * 0.334) + ((value - 300) * 0.516);
                    } else {
                        cost = (200 * 0.218) + (100 * 0.334) + (300 * 0.516) + ((value - 600) * 0.546);
                    }

                    finalCost = cost - (cost * (rebate/100));

                    String formattedCost = String.format("%.2f", finalCost);
                    tvOutput.setText(formattedCost);
                }catch (NumberFormatException nfe) {

                    Toast.makeText(getApplicationContext(),"Please enter the value and rebate", Toast.LENGTH_SHORT).show();
                }
            }
        });
        }
        @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            MenuInflater inflater = getMenuInflater();
            inflater.inflate(R.menu.menu, menu);
            return true;
    }

        public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.item_about){
            Intent aboutIntent = new Intent (this, AboutActivity.class);
            startActivity(aboutIntent);
            return true;
        }
        return false;
        }
    }